package com.pingan.redis;



public class RedisDemo {
	public static void main(String[] args) {
		RedisUtils.getKeys();
		
	}
}
