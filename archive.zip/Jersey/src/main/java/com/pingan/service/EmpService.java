package com.pingan.service;

import org.springframework.stereotype.Service;


@Service("zhouqiang")
public class EmpService {
	
	public String getEmp(){
		return "我是周强！";
	}

}
