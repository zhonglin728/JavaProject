package com.pingan.service;


public class OaService {
	public String getOa(){
		return "返回OA  service!";
	}

}
