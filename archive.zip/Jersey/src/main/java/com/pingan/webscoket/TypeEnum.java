package com.pingan.webscoket;

public enum TypeEnum {
	QUERY,ADD,UPDATE,DELETE

}
