package com.service.auth.serviceauth.config;

public class Utils {
    public static class RESOURCEIDS {
        static final String ORDER = "order";
    }
}
